# رباعیات خیام — نسخه آماده Build ابری

این پروژه برای ساخت APK با GitHub Actions آماده شده است.

## روش کلی
1. این پوشه را در یک repository گیت‌هاب قرار دهید.
2. از تب Actions، workflow با نام Build APK را اجرا کنید.
3. پس از پایان موفق Build، از بخش Artifacts فایل `robaiyat-khayyam-apk` را دریافت کنید.

## نکته
این نسخه APK آزمایشی (debug) می‌سازد و برای نصب روی گوشی مناسب است.
